/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.lab;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 *
 * @author 5000078
 */
public class ValidationUtils {
       /**
     * Corrige XSS persistente a través de HTML Encoding
     * @param mensaje
     * @param enc
     * @return String sin caracteres "peligrosos"
     * @throws UnsupportedEncodingException 
     */
    public static String encode(String mensaje) throws UnsupportedEncodingException {
        return URLEncoder.encode(mensaje, "UTF-8");
    }
    
    /**
     * Reemplaza caracteres significativos en XML por versiones "inofensivas"
     * de acuerdo a http://www.w3.org/TR/html4/sgml/entities.html 
     * @param mensaje
     * @return la cadena con los caracteres reemplazados
     */
    public static String desinfecta(String mensaje) {
        StringBuilder msg = new StringBuilder(mensaje);
        mensaje = mensaje.replaceAll("<","&lt;");
        mensaje = mensaje.replaceAll(">","&gt;");
        mensaje = mensaje.replaceAll("&","&amp;");
        mensaje = mensaje.replaceAll("\"","&quot;");
        mensaje = mensaje.replaceAll("'","&#x27;");
        mensaje = mensaje.replaceAll("/","&#x2F;");
        return mensaje;
    }
}
