/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.lab;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import javax.servlet.http.HttpServlet;

/**
 *
 * @author 5000078
 */
public class DBConnection {

    private Connection conn;
    private HttpServlet servlet;

    public DBConnection(HttpServlet servlet) {
        this.servlet = servlet;
    }

    public ResultSet getEmpleadoByID(String id) {
        ResultSet resultados = null;

        try {
            conn = getConnection();

            String sqlString = "SELECT * FROM empleados "
                    + "WHERE userID = '" + id + "' ";        // FIX - ?

            System.err.println(sqlString); // para verlo en la consola
            Statement stmt = conn.createStatement();        // FIX - P
            resultados = stmt.executeQuery(sqlString);
        } catch (SQLException sqlex) {
            System.err.println("ERROR al obtener los empleados");
        }
        return resultados;
    }

        public ResultSet getEmpleadoByLocation(String ubica) {
        ResultSet resultados = null;

        try {
            conn = getConnection();

            String sqlString = "SELECT * FROM empleados "
                    + "WHERE ubicacion = " + ubica + " ";        // FIX - ?

            System.err.println(sqlString); // para verlo en la consola
            Statement stmt = conn.createStatement();        // FIX - P
            resultados = stmt.executeQuery(sqlString);
        } catch (SQLException sqlex) {
            System.err.println("ERROR al obtener los empleados");
        }
        return resultados;
    }
        
    public ResultSet getEmpleadoByCode(String id, String code) {
        ResultSet resultados = null;

        try {
            conn = getConnection();

            String sqlString = "SELECT * FROM empleados "
                    + "WHERE userID = '" + id + "' AND codigo = '" + code + "' ";        // FIX - ?

            System.err.println(sqlString); // para verlo en la consola
            Statement stmt = conn.createStatement();        // FIX - P
            resultados = stmt.executeQuery(sqlString);
        } catch (SQLException sqlex) {
            sqlex.printStackTrace();
        }
        return resultados;
    }

        
    private Connection getConnection() throws SQLException {
        String dbConnection = "jdbc:derby://localhost:1527/SecureCoding";

        // *** ¡NO deben almacenarse datos de conexión en el código!
        String username = getProperty("db_user");
        String password = getProperty("db_pass");
        System.out.println("****" + username + ", " + password);
        return DriverManager.getConnection(dbConnection, username, password);
    }

    private String getProperty(String p) {
        ClassLoader classLoader
                = Thread.currentThread().getContextClassLoader();
        Properties properties = new Properties();

        try {
            properties.load(
                    servlet.getServletContext().getResourceAsStream(
                            "/WEB-INF/secrets.properties"));
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return properties.getProperty(p);

    }
}
